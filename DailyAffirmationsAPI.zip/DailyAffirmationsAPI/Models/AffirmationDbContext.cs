﻿using Microsoft.EntityFrameworkCore;

namespace DailyAffirmationsAPI.Models
{
    public class AffirmationDbContext:DbContext
    {
        public AffirmationDbContext(DbContextOptions<AffirmationDbContext> options) : base(options) { }

        public DbSet<Affirmation> Affirmations { get; set; }
    }
}
