﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace DailyAffirmationsAPI.Models
{
    public class Affirmation
    {

        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage ="Kindly Provide the Message!")]
        public string Message { get; set; }

        [Required(ErrorMessage ="Kindly Describe the Category!")]
        public String Category { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateOnly CreatedDate { get; set; }
    }
}
