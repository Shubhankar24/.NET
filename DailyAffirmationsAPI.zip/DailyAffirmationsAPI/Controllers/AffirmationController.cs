﻿using DailyAffirmationsAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DailyAffirmationsAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AffirmationController : ControllerBase
    {
        public AffirmationDbContext context;

        public AffirmationController(AffirmationDbContext _context)
        {
            context = _context;
        }
        // similar to index
        [HttpGet]
        public IActionResult GetAllAffirmation()
        {
            List<Affirmation> affirm = context.Affirmations.ToList();
            return Ok(affirm);
        }

        // similar to details (Read Method)
        [HttpGet("{id}")]
        public IActionResult GetAffirmationById(int id)
        {
            Affirmation affi = context.Affirmations.Find(id);
            return Ok(affi);
        }

        // similar to create  (Create Method)

        [HttpPost]
        public IActionResult AffirmationCreate(Affirmation af)
        {
            context.Affirmations.Add(af);
             context.SaveChanges();
            return CreatedAtAction(nameof(GetAffirmationById), new { id = af.Id },af);
        }

        // similar to Update  (Update Method)
        [HttpPut("{id}")]
        public IActionResult UpdateAffirmation(int id, Affirmation af)
        {
            if (id != af.Id) return BadRequest();

            context.Affirmations.Update(af);
            context.SaveChanges();

            return Ok();

        }

        // similar to delete (Delete Method)
        [HttpDelete("{id}")]

        public IActionResult DeleteAffirmation(int id)
        {
            Affirmation af = context.Affirmations.Find(id);

            if (af == null) return NotFound();

            context.Affirmations.Remove(af);
            context.SaveChanges();
            return Ok("Affirmation Deleted Successfully.");
        }

    }
}

// id required for --> read, update and delete method 