﻿using System.ComponentModel.DataAnnotations.Schema;

namespace SoloTravelAPI.Models
{
    [Table("SoloTrip")]
    public class SoloTrip
    {
        public int Id { get; set; }

        public string Destination { get; set; }

        public string TDescription { get; set; }

        public DateTime TravelDate { get; set; }

        public string TravelName { get; set; }
    }
}
