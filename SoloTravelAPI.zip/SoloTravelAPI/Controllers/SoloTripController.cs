﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SoloTravelAPI.Models;

namespace SoloTravelAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SoloTripController : ControllerBase
    {
// in web Api we use this return rather then returning RedirectToAction()
// Ok(...)

//CreatedAtAction(...)

//BadRequest(...)

//NotFound()


        public ApiDbContext context;

        public SoloTripController(ApiDbContext _context)
        {
            context = _context;
        }

        [HttpGet]
        // can also name Index as GetAllTrips, FetchAll
        public IActionResult GetTrip()
        {
            List<SoloTrip> trips = context.SoloTrips.ToList();
            // List<SoloTrip> trips = context.SoloTrips.ToList();
            return Ok(trips);
        }

        [HttpGet]
        [Route("tripById")]
        // similar to get method of  Create in CFA
        public IActionResult GetTripById(int id)
        {
            SoloTrip solotrip = context.SoloTrips.Where(x=>x.Id == id).ToList().FirstOrDefault();
            
            if (solotrip == null) return NotFound();

            return Ok(solotrip);
        }

        [HttpPost]
        
        public IActionResult AddNewTrip(SoloTrip trip)
        {
            context.SoloTrips.Add(trip);
            context.SaveChanges();
            //return Ok(trip);
            return CreatedAtAction(nameof(GetTripById), new { id = trip.Id }, trip);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateTrip(int id, SoloTrip trip)
        {
            //if (id != trip.Id) return BadRequest("Trip Id Mismatch");

            //context.SoloTrips.Update(trip);
            //context.SaveChanges();
            //return Ok("Trip Updated Successfully");
            try
            {
                if (id != trip.Id)
                {
                    return BadRequest();
                }
                context.Update(trip);
                context.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }


        }

        [HttpDelete]
        public IActionResult DeleteTrip(int id)
        {
            //SoloTrip trip = context.SoloTrips.Find(id);
            SoloTrip trip = context.SoloTrips.Where(x => x.Id == id).ToList().FirstOrDefault();
            if (trip == null) return NotFound();

            context.Remove(trip);
            context.SaveChanges();
            return Ok("Trip Deleted Successfully");
        }


    }
}
