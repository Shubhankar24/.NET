﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MotivationalQuotesManager.Models;

namespace MotivationalQuotesManager.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuotesController : ControllerBase
    {
        public QuotesDbContext context;

        public QuotesController(QuotesDbContext _context)
        {
            context = _context;
        }

        // creating index page or homePage  
        [HttpGet]
        public IActionResult GetQuotes()
        {
            List<Quote> quote = context.Quotes.ToList();
            return Ok(quote);
        }

        // obtaining details
        [HttpGet]
        [Route("quoteById")]
        public IActionResult GetQuoteById(int id)
        {
            var quote = context.Quotes.Where(x => x.QuoteId == id).ToList().FirstOrDefault();
            if (quote == null)
            {
                return NotFound();
            }
            return Ok(quote);
        }

        // adding data  
        [HttpPost]
        public IActionResult createQuote(Quote q)
        {
             
            context.Quotes.Add(q);
            context.SaveChanges();
            return CreatedAtAction(nameof(GetQuoteById), new { id = q.QuoteId }, q);
        }

        // updaing data 
        [HttpPut("{id}")]
        public IActionResult updateQuote(int id, Quote q)
        {
            try
            {
                if (id != q.QuoteId)
                {
                    return BadRequest();
                }
                context.Quotes.Update(q);
                context.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // deleting the quotes from database 
        [HttpDelete]
        public IActionResult DeleteQuote(int id)
        {
            var quote = context.Quotes.Where(x => x.QuoteId == id).ToList().FirstOrDefault();
            if(quote == null)
            {
                return NotFound();
            }
            context.Quotes.Remove(quote);
            context.SaveChanges();
            return Ok("Record Deleted Successfully");
        }


    }
}
