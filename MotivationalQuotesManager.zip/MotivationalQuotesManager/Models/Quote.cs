﻿using System.ComponentModel.DataAnnotations;

namespace MotivationalQuotesManager.Models
{
    public class Quote
    {
        [Key]
        public int QuoteId { get; set; }

        [Required(ErrorMessage="Text is Required!")]
        public string Message { get; set; }

        [Required(ErrorMessage ="Author Name is Required!")]
        public string Author { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateOnly CreatedDate { get; set; }

    }
}
