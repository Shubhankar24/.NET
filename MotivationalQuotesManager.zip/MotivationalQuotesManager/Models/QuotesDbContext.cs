﻿using Microsoft.EntityFrameworkCore;

namespace MotivationalQuotesManager.Models
{
    public class QuotesDbContext:DbContext
    {

        public QuotesDbContext(DbContextOptions<QuotesDbContext> options) : base(options) { }


        public DbSet<Quote> Quotes { get; set; }
    }
}
