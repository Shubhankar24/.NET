﻿using System;
using System.Collections.Generic;

namespace MoodJournalApp.Models;

public partial class MoodEntry
{
    public int MoodId { get; set; }

    public DateOnly MoodDate { get; set; }

    public string MoodType { get; set; } = null!;

    public string? Notes { get; set; }
}
