﻿using System.ComponentModel.DataAnnotations;

namespace PlantCareDiary.Models
{
    public class PlantLog
    {

        // LogId(int), PlantName(string), Activity(string), DurationInMinutes(int), CareDate(date), Notes(string)

        [Key]
        public int LogId { get; set; }

        [Required(ErrorMessage ="Plant Name is Required!")]
        public string PlantName {get;set;}

        [Required(ErrorMessage="Activity is Required!")]
        public string Activity { get; set; }

        [Required(ErrorMessage="Duration is Required!")]
        public int DurationInMinutes { get; set; }

        [Required(ErrorMessage ="CareDate is Required!")]
        [DataType(DataType.Date)]
        public DateOnly CareDate { get; set; }

        [Required(ErrorMessage ="Notes is Required!")]
        public string Notes { get; set; }




    }
}
