﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;

namespace PlantCareDiary.Models
{
    public class PlantDbContext:DbContext
    {
        public PlantDbContext(DbContextOptions<PlantDbContext> options) : base(options) { }

        public DbSet<PlantLog> PlantLogs { get; set; }  

    }
}
