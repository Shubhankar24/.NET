﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Client;
using PlantCareDiary.Models;

namespace PlantCareDiary.Controllers
{
    public class PlantLogsController : Controller
    {
        public PlantDbContext context;

        public PlantLogsController(PlantDbContext _context)
        {
            context = _context;
        }

        public IActionResult Index()
        {
            List<PlantLog> logs = context.PlantLogs.ToList();
            return View(logs);
        }

        //details 
        [HttpGet]
        public IActionResult Details(int id)
        {
            // here ? --> stores null value at time of declaration bcz we don't the exact value right now 
            PlantLog? log = context.PlantLogs.Find(id);
            return View(log);
        }

        // create (details)
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(PlantLog p)
        {
            if (ModelState.IsValid)
            {
                context.PlantLogs.Add(p);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(p);
        }

        // edit (view)
        [HttpGet]
        public IActionResult Edit(int id)
        {
            PlantLog p = context.PlantLogs.Find(id);
            if (p == null)
            {
                return NotFound();
            }
            return View(p);
        }

        // editing concept
        [HttpPost]
        public IActionResult Edit(int id, PlantLog p)
        {
            if(id != p.LogId)
            {
                return BadRequest();
            }
            context.PlantLogs.Update(p);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        // show before delete 
        [HttpGet]
        public IActionResult Delete(int id)
        {
            PlantLog p = context.PlantLogs.Find(id);
            if(p == null)
            {
                return NotFound();
            }
            return View(p);
        }

        // actual deletion 
        [HttpPost]
        [ActionName("Delete")]
        public IActionResult DeleteConfirm(int id)
        {
            PlantLog p = context.PlantLogs.Find(id);

            if(p == null)
            {
                return NotFound();
            }
            context.PlantLogs.Remove(p);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
